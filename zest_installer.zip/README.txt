How to use ZEST 

1.) Run setup.cmd. This will open Command line and unpack all necessary files
needed to run Zest. A shortcut for Zest will appear in the Desktop

2.) Zest can be opened by running the Zest shortcut in the Desktop and
Start Menu.

3.) Zest can be uninstalled shortcut that can be found in the start menu.