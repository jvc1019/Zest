$("#sidebar").hover(
    function () {
        $(this).css("width", "250px");
    },
    function () {
        $(this).css("width", "90px");
    }
);
